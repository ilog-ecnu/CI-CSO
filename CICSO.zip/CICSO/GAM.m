classdef GAM < handle
    properties
        n_splines
        model
    end
    
    methods
        function obj = GAM(n_splines)
            obj.n_splines = n_splines;
        end
        
        function fit(obj, x, y)
            % Check `x` dimensionality
            if ~ismatrix(x)
                error('`x` should be a 2D array.');
            end
            
            % Create B-spline basis for each dimension
            basis = create_bspline_basis(x, obj.n_splines);
            
            % Fit the model
            obj.model = fdaM(y, x, basis);
        end
        
        function y_pred = predict(obj, x)
            y_pred = eval_fd(x, obj.model);
        end
    end
end

function basis = create_bspline_basis(x, n_splines)
    % Create B-spline basis for each dimension
    n_dims = size(x, 2);
    range_x = cell(1, n_dims);
    
    for i = 1:n_dims
        range_x{i} = [min(x(:, i)), max(x(:, i))];
    end
    
    basis = create_bspline_basis_fun(n_dims, n_splines, range_x);
end
