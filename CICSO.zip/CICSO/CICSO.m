classdef CICSO < ALGORITHM
    % <multi/many> <real> <large/none> <constrained/none>
    % A Two-Population Algorithm for Large-Scale Multi-objective Optimization Based on Fitness-Aware Operator and Adaptive Environmental Selection
    % Li, Bingdong and Zhang, Yan and Yang, Peng and Yao, Xin and Zhou, Aimin
    %
    %------------------------------- Reference --------------------------------
    % B. Li, Y. Zhang, P. Yang, X. Yao, and A. Zhou,
    % “A two-population algorithm for large-scale multi-objective optimization
    % based on fitnessaware operator and adaptive environmental selection,”
    % IEEE Transactions on Evolutionary Computation, 2023.
    % https://github.com/ilog-ecnu/LSTPA.git
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
    % research purposes. All publications which use this platform or any code
    % in the platform should acknowledge the use of "PlatEMO" and reference "Ye
    % Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
    % for evolutionary multi-objective optimization [educational forum], IEEE
    % Computational Intelligence Magazine, 2017, 12(4): 73-87".
    %--------------------------------------------------------------------------
    
    methods
        function main(Algorithm,Problem)
            %% Generate random population
            [V,Problem.N] = UniformPoint(Problem.N,Problem.M);
            Population    = Problem.Initialization();
            Population    = EnvironmentalSelection(Population,V,(Problem.FE/Problem.maxFE)^2);
            
            PreF = calFitness(Population.objs); % (2)
            CurF=  calFitness(Population.objs); % (2)
            Pre=Population;
            Cur=Pre;
            
            P=[];
            Fit=[];
            cnt=1;
            ArcP=cell(10,1);
            FitP=cell(10,1);
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                Fitness = calFitness(Population.objs); % (2)
                [tFrontNo,Fitness1] = tNDSortFitness(Population.objs,V,(Problem.FE/Problem.maxFE)^2);
                ct=mod(cnt,10)+1;
                ArcP{ct}=Population;
                FitP{ct}=Fitness1';
                Cur=Population;
                CurF=Fitness;
                
                flag=1;
                
                TP=[];%历史种群存档
                FP=[];%历史种群适应度值存档
                
                for c=1:10
                    TP=[TP,ArcP{c}];
                    FP=[FP;FitP{c}];
                end
                D1=TP.decs;
                [F1,a]=HelpDiv(TP,10);
                if size(D1,1)>=20
                    L1=getCiEffects(TP.decs,FP);
                    index1=find(L1>=0);
                    index2=find(L1<0);
                    flag=0;
                else
                    index1=0;
                    index2=0;
                    L1=0;
                    
                end
                cnt=cnt+1;
                if length(Population) >= 2
                    Rank = randperm(length(Population),floor(length(Population)/2)*2);
                else
                    Rank = [1,1];
                end
                Loser  = Rank(1:end/2);
                Winner = Rank(end/2+1:end);
                Change = Fitness(Loser) >= Fitness(Winner);
                Temp   = Winner(Change);
                Winner(Change) = Loser(Change);
                Loser(Change)  = Temp;
                
                FitnessDiff = (Fitness(Winner)-Fitness(Loser))./Fitness(Winner);        % (7)
                P1=Population(Loser);
                P2=Population(Winner);
                Offspring      = CIbasedOperator(P1,P2,index1,index2,flag,L1,F1,a,FitnessDiff,Problem);
                Population     = EnvironmentalSelection([Population,Offspring],V,(Problem.FE/Problem.maxFE)^2);
                
            end
        end
    end
end

function Fitness = calFitness(PopObj)
    % Calculate the fitness by shift-based density

    N      = size(PopObj,1);
    fmax   = max(PopObj,[],1);
    fmin   = min(PopObj,[],1);
    PopObj = (PopObj-repmat(fmin,N,1))./repmat(fmax-fmin,N,1);
    Dis    = inf(N);
    for i = 1 : N
        SPopObj = max(PopObj,repmat(PopObj(i,:),N,1));
        for j = [1:i-1,i+1:N]
            Dis(i,j) = norm(PopObj(i,:)-SPopObj(j,:));
        end
    end
    Fitness = min(Dis,[],2);
end