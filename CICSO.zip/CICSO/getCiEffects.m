function fr=getCiEffects(Dec1,Fit1)
% 获取每一维决策变量与适应度值之间的因果关系
    Contri=[];
    for i=1:size(Dec1,2)
        D1=Dec1(:,i);
        sum1=0;
        for j=1:size(Fit1,2)
            t_obj=Fit1(:,j);          
            c1=igci(D1,t_obj,2,2);%调用IGCI方法
            sum1=sum1+c1;
        end
        Contri=[Contri,sum1./size(Fit1,2)];
    end
    fr=Contri;
end