function [val,a]=HelpCIprocess(Population,RefNo)
% 获取优劣解间决策变量差值
Pobjs=Population.objs;
 NV=size(Pobjs,1);
[Front,MaxFront] = NDSort(Pobjs,min([NV,NV]));
    if  sum(Front==1) >= RefNo  
        Next0 = Front < MaxFront;
        Last = find(Front == MaxFront);
    else
        Next0 = Front == 1;
        Last = find(Front >1);
    end
     P1 = Population(Last);
     P2 = Population(Next0);
     a=min(size(P1,2),size(P2,2));
     P1=P1(:,1:a);
     P2=P2(:,1:a);
     val=P1.decs-P2.decs;
end