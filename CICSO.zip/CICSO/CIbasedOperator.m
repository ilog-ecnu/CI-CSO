function Offspring =  CIbasedOperator(Loser,Winner,index1,index2,flag,L1,F1,a,FitnessDiff,Problem)
% The competitive swarm optimizer of LSTPA

%% Parameter setting
LoserDec  = Loser.decs;
WinnerDec = Winner.decs;
[N,D]     = size(LoserDec);
LoserVel  = Loser.adds(zeros(N,D));
WinnerVel = Winner.adds(zeros(N,D));
Lower   = repmat(Problem.lower,N,1);
Upper   = repmat(Problem.upper,N,1);
%     Problem   = PROBLEM.Current();

%% Competitive swarm optimizer

meanr2 = mean(FitnessDiff);
coeff = mean(power(10,FitnessDiff));

FitnessDiff = repmat(FitnessDiff,1,D);
if size(F1,1)>1
    val1=mean(F1);
else
    val1=F1;
end
meanr2 = mean(FitnessDiff);
coeff = mean(power(10,FitnessDiff));

FitnessDiff = repmat(FitnessDiff,1,D);
r1     = repmat(rand(N,1),1,D);
r2     = repmat(rand(N,1),1,D);

OffVel = r1.*LoserVel + r2.*(WinnerDec-LoserDec);
OffDec = LoserDec + OffVel + r1.*(OffVel-LoserVel);%LMOCSO
ind1=find(L1<0);
S1=L1(ind1);
S1=-1.*S1;
S11= mapminmax(S1, 0, 1);  %��׼����ֵ
sigma=std(S1);
if a==0
    WinnerDec=WinnerDec;
else
    indc1=val1(ind1);
    val2=indc1;
%     ���HelpCIPȷ������͸���Ӱ��
    ind2=ind1(find(val2>0));
    ind3=ind1(find(val2<0));
    if size(ind2,2)==0 || size(ind3,2)==0
        WinnerDec=WinnerDec;
        
    else
        S2=L1(ind2);
        S3=L1(ind3);
        S2=-1.*S2;
        S3=-1.*S3;
        S12= mapminmax(S2, 0, 1);
        S13= mapminmax(S3, 0, 1);
        sigma1=std(S12);
        sigma2=std(S13);
        OffDec(:,ind2)  = repmat(normrnd(0,sigma1,[N,1]),1,size(ind2,2)).*WinnerDec(:,ind2)+OffDec(:,ind2);
        WinnerDec(:,ind2)  = repmat(normrnd(0,sigma1,[N,1]),1,size(ind2,2)).*WinnerDec(:,ind2)+OffDec(:,ind2);
        OffDec(:,ind3)  = repmat(normrnd(0,sigma2,[N,1]),1,size(ind3,2)).*WinnerDec(:,ind3).*-1+OffDec(:,ind3);
        WinnerDec(:,ind3)  = repmat(normrnd(0,sigma2,[N,1]),1,size(ind3,2)).*WinnerDec(:,ind3).*-1+OffDec(:,ind3);
        
    end
end



%% Add the winners
OffDec = [OffDec;WinnerDec];
OffVel = [OffVel;WinnerVel];

%% Polynomial mutation
Lower  = repmat(Problem.lower,2*N,1);
Upper  = repmat(Problem.upper,2*N,1);
disM   = 20;
Site   = rand(2*N,D) < 1/D;
mu     = rand(2*N,D);
%     index_1=[1:size(OffDec,1)];
% index_1=[1:round(size(OffDec,1)./2)];
% index_2=[round(size(OffDec,1)./2)+1:size(OffDec,1)];
index_1=randperm(size(OffDec,1),round(0.5.*size(OffDec,1)));
%   if size(Pre,1)>20 && size(Cur,1) > 20
%     temp   = Site & mu<=0.5;
OffDec       = max(min(OffDec,Upper),Lower);
idx = kmeans(OffDec,2);
%     if flag==1
temp   = Site & mu<=0.5;
OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
    (1-(OffDec(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);

%     else
%         temp=index2;
%
%
%         OffDec(index_1, temp) = OffDec(index_1, temp)+(Upper(index_1, temp)-Lower(index_1, temp)).*((2.*mu(index_1, temp)+(1-2.*mu(index_1, temp)).*...
%             (1-(OffDec(index_1, temp)-Lower(index_1, temp))./(Upper(index_1, temp)-Lower(index_1, temp))).^(disM+1)).^(1/(disM+1))-1);
%
%     end

%    temp  = Site & mu>0.5;
%     if flag==1
temp   = Site & mu>0.5;
OffDec(temp) = OffDec(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
    (1-(Upper(temp)-OffDec(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));

%     else
%         temp=index1;
%         %          OffDec(index_2, temp) = OffDec(index_2, temp)+(Upper(index_2, temp)-Lower(index_2, temp)).*(1-(2.*(1-mu(index_1, temp))+2.*(mu(index_1, temp)-0.5).*...
%         %                    (1-(Upper(index_2, temp)-OffDec(index_2, temp))./(Upper(index_2, temp)-Lower(index_2, temp))).^(disM+1)).^(1/(disM+1)));
%
%         OffDec(index_1, temp) = OffDec(index_1, temp)+(Upper(index_1, temp)-Lower(index_1, temp)).*(1-(2.*(1-mu(index_1, temp))+2.*(mu(index_1, temp)-0.5).*...
%             (1-(Upper(index_1, temp)-OffDec(index_1, temp))./(Upper(index_1, temp)-Lower(index_1, temp))).^(disM+1)).^(1/(disM+1)));
%
%     end
% temp=index2;
Offspring = Problem.Evaluation(OffDec,OffVel);
end